rootProject.name = "gradle-catalog-kotlin"

include(":gradle-catalog-kotlin")

dependencyResolutionManagement {
    versionCatalogs
}
plugins {
    kotlin("multiplatform")
}

kotlin {
    jvm()
    ios()



    sourceSets {

        commonMain {
            dependencies {
                implementation("io.ktor:ktor-server-cio:2.3.4")
                implementation("org.jetbrains.kotlinx:kotlinx-datetime:0.5.0")
                implementation("org.jetbrains.kotlinx:kotlinx-html:0.10.1")
                implementation("org.danbrough.kotlinx:kotlinx-html:0.8.0")
            }
        }
        commonTest {
            dependencies {
            }
        }
//        val iosMain by getting {
//            dependencies {
//                implementation("io.ktor:ktor-client-cio:2.3.4")
//            }
//        }
    }
}

val derp by configurations.creating

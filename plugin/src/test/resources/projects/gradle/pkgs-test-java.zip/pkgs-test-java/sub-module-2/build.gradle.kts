plugins {
    id("java")
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    implementation("aws.sdk.kotlin:aws-http:1.0.78")
    implementation("com.netflix.servo:servo-apache:0.13.2")
}

tasks.test {
    useJUnitPlatform()
}
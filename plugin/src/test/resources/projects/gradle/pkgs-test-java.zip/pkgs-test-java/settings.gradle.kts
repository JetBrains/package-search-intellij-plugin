rootProject.name = "pkgs-test-java"
include("sub-module-1", "sub-module-2", "non_existent_module")
